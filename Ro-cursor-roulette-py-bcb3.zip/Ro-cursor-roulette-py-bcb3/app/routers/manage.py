"""
This router is deprecated in favor of app/routers/my.py and has been intentionally removed
to avoid duplication and dead/unwired code paths.
"""
